<?php

$_lang['area_wrapyoutube_main'] = 'Main';

$_lang['setting_wrapyoutube_tpl'] = 'Chunk for wrap';
$_lang['setting_wrapyoutube_excluded_templates'] = 'Excluded templates';
