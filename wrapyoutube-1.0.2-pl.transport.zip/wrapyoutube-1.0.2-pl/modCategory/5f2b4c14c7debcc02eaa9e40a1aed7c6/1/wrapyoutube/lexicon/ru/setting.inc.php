<?php

$_lang['area_wrapyoutube_main'] = 'Основные';

$_lang['setting_wrapyoutube_tpl'] = 'Чанк для оборачивания';
$_lang['setting_wrapyoutube_excluded_templates'] = 'Отключён в шаблонах';
