--------------------
wrapYoutube
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

Wrapping youtube iframes with links for faster loading

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/ilyautkin/wrapYoutube/issues