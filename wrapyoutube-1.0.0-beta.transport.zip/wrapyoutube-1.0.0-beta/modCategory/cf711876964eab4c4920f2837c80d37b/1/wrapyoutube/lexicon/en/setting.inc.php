<?php

$_lang['area_wrapyoutube_main'] = 'Main';

$_lang['setting_wrapyoutube_tpl'] = 'Chunk for wrap';
