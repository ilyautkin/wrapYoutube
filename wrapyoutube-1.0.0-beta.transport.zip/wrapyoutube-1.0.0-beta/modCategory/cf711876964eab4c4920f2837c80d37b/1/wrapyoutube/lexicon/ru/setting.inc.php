<?php

$_lang['area_wrapyoutube_main'] = 'Основные';

$_lang['setting_wrapyoutube_tpl'] = 'Чанк для оборачивания';
